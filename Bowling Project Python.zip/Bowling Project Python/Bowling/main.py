# Get user Input
game_tally = "5/|5/|5/|5/|5/|5/|5/|5/|5/|5/||5"

# Split unneeded chars
game_tally_split = game_tally.replace("|", "")

# Put the records in a list
list_records = [record for record in game_tally_split]

print(list_records)
print(len(list_records))
list_score_records = []

# Generate list of index, because pythons .index method only returns the first index of a char
# it will not generate a new index for duplicates of that char.
list_of_indexes = [i for i in range(0, len(list_records))]

# Counter to iterate through the loop
count = 0
while count < len(list_of_indexes):
    # if count == 19
    # Create a temp list to add to our larger list for easy score indexing access
    list_temp = []

    if count == 19:

        # Checks if there is another score frame
        if len(list_of_indexes) > 20:

            list_temp.append(list_records[list_of_indexes[count + 1]])
            list_score_records.append(list_temp)
            break;

        else:
            break;
# if the 9/10th index == X
    if count == len(list_of_indexes) - 2 and list_records[count] == "X":

        primary = list_records[list_of_indexes[count + 1]]
        secondary = list_records[list_of_indexes[count + 1]]
        list_temp.append(primary)
        list_temp.append(secondary)
        list_score_records.append(list_temp)
        break;

    elif list_records[list_of_indexes[count]] == "X":

        # Add X
        list_temp.append(list_records[list_of_indexes[count]])
        list_score_records.append(list_temp)
        count += 1


    elif list_records[list_of_indexes[count]] == "-":

        # If the character is a - then add a 0 for a miss, then add the ball score after it
        list_temp.append(0)

        # then add the ball score after the miss
        append_record = list_records[list_of_indexes[count + 1]]
        list_temp.append(append_record)

        # Get the index to use in replacement
        temp = list_of_indexes[count + 1]
        # list_temp.append(list[count + 1])
        # Change the "-" to an empty String
        list_records[list_of_indexes[temp]] = ""

        # Append the temp list to our score records list
        list_score_records.append(list_temp)
        count += 1

    # If we run into an empty char, skip it.
    elif list_records[list_of_indexes[count]] == "":
        count += 1
        pass


    else:

        # Add the ball's number score
        list_temp.append(int(list_records[list_of_indexes[count]]))

        # Get the next index (which will be an icon or number) after the first ball
        append_record = list_records[list_of_indexes[count + 1]]

        # Add it to the temp list
        list_temp.append(append_record)

        # Set temp to an index of our list of indexes that is equal to count
        # (count is the current index of the iteration)
        temp = list_of_indexes[count + 1]

        # Change the element at our list of records to an empty char
        # list_records[list_of_indexes[temp]] = ""
        list_records[temp] = ""

        # Finally, add the new temp list to our score records
        list_score_records.append(list_temp)

        # Add one to count to properly iterate through the loop
        count += 1

print(list_score_records)
print(len(list_score_records))

# List, Index


score = 0
count = 0

# Replace left over misses with 0's and X's with 10s
# Record is a list within our list of lists (list_score_records)
for record in list_score_records:

    if len(record) > 1:

        if record[1] == "-":
            record[1] = 0

        elif record[1] == "/":
            record[1] = 10 - record[0]

        elif record[1] == "X":
            if record[0] == "X":
                record[0] = 10
                record[1] = 10

    elif record[0] == "X":
        record[0] = 10
    # else:
    #     record[0] = 10



print("Length", len(list_score_records))
print("List of liusts", list_score_records)

# print(list_score_records[2][0])
count = 0
strike_index = 0
scoreboard = []
for i in range(0, len(list_score_records)):
    record = list_score_records[i]

    # Calculate final tally
    if len(list_score_records) == 11 and i == 9:

        # Get the final record
        final_record = list_score_records[i + 1]
        if len(record) > 1:

            primary = record[0]
            secondary = record[1]
            spare_check = int(primary) + int(secondary)

        # Check if the final record has double values
        if len(final_record) > 1:

            primary = final_record[0]
            secondary = final_record[1]
            score = int(record[0]) + int(primary) + int(secondary)
            scoreboard.append(score)

            break;

        else:

            primary = final_record[0]
            score = int(spare_check) + int(primary)
            scoreboard.append(score)

            break;


    elif record[0] == 10:

        strike_index = i
        # print("Strike", strike_index)

        # Get the sublist within the list_score_records
        round = list_score_records[strike_index + 1]

        if len(round) > 1:

            primary = round[0]
            secondary = round[1]
            score = record[0] + int(primary) + int(secondary)

            scoreboard.append(score)

        else:

            round2 = list_score_records[strike_index + 2]
            primary = round[0]
            secondary = round2[0]
            score = record[0] + int(primary) + int(secondary)

            scoreboard.append(score)

            #count += 1

    # Logic for spare
    elif len(record) > 1:

        primary = record[0]
        secondary = record[1]
        spare_check = int(primary) + int(secondary)

        # Check if the scores in the record == 10
        if spare_check == 10:

            round2 = list_score_records[i + 1]
            primary = round2[0]
            score = 10 + int(primary)
            scoreboard.append(score)

        else:

            score = spare_check
            scoreboard.append(score)

print(scoreboard)
print(sum(scoreboard))

